import os
from flask import Flask, request, jsonify
import pymongo
import requests
from flask_cors import CORS

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# MongoDB client setup
client = pymongo.MongoClient(os.getenv('MONGO_URI', 'mongodb://mongo:27017/'))
db = client['app_database']
recipes_collection = db['recipes']

@app.route('/')
def home():
    return jsonify({"message": "Welcome to the Microservices App!"})

# Recipe service endpoint
@app.route('/recipes', methods=['GET', 'POST'])
def recipes():
    if request.method == 'POST':
        data = request.json
        recipes_collection.insert_one(data)
        return jsonify({"message": "Recipe added successfully!"}), 201

    recipes = list(recipes_collection.find({}, {"_id": 0}))
    return jsonify(recipes)

# Example external service call
@app.route('/external', methods=['GET'])
def external_service():
    response = requests.get('https://api.example.com/data')
    return jsonify(response.json())

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
